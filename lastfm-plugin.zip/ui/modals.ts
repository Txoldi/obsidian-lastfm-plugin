import { App, Modal, Setting, Notice } from "obsidian";
import type { LastFmTrack } from "../lastfm/types";
import LastFmPlugin from "main";
import { LastFmApi } from "../lastfm/api";
import { createRecentTracksNote } from "../commands/noteCommands";

// Tabs
type SectionName = "recent" | "topTracks" | "topArtists" | "topAlbums";

// Period options per Last.fm docs
const PERIODS = [
	"7day",
	"1month",
	"3month",
	"6month",
	"12month",
	"overall"
];

export class LastFmModal extends Modal {
    private api: LastFmApi;
    private plugin: LastFmPlugin

    private activeSection: SectionName = "recent";

    private limit: number = 10; //shared default value

    // For Top sections
	private topMode: "period" | "range" = "period";
	private topPeriod: string = "7day";
	private fromDate: string = "";
	private toDate: string = "";

    constructor(app: App, api:LastFmApi, plugin:LastFmPlugin){
        super(app);
        this.api = api;
        this.plugin = plugin;
    }

    onOpen() {
        this.modalEl.addClass("lastfm-modal");
        this.redraw();
    }

    private redraw() {
        const { contentEl } = this;
        contentEl.empty();

        /* --------------------------
         * TABS
         * -------------------------- */
		const tabs = contentEl.createDiv("lastfm-tabs");

        this.createTabButton(tabs, "recent", "Recent Scrobbles");
		this.createTabButton(tabs, "topTracks", "Top Tracks");
		this.createTabButton(tabs, "topArtists", "Top Artists");
		this.createTabButton(tabs, "topAlbums", "Top Albums");

        contentEl.createEl("hr");

        /* --------------------------
         * SECTION RENDERING
         * -------------------------- */
		if (this.activeSection === "recent") 
            this.renderRecentSection(contentEl);
		if (this.activeSection === "topTracks")
			this.renderTopSection(contentEl, "tracks");
		if (this.activeSection === "topArtists")
			this.renderTopSection(contentEl, "artists");
		if (this.activeSection === "topAlbums")
			this.renderTopSection(contentEl, "albums");

    }

    onClose() {
        this.contentEl.empty();
    }

	/* ---------------------------------------------------
     * TABS
     * --------------------------------------------------- */
	private createTabButton(container: HTMLElement, name: SectionName, label: string) {
		const btn = container.createEl("button");

        // Active class?
        if (this.activeSection === name) {
            btn.addClass("active");
        }
        
        // ICON
        const iconSpan = btn.createSpan({
            cls: "lastfm-tab-icon " + name // CSS class determines which icon to show
        });
        
        // LABEL
        btn.createSpan({ text: label });

        // Click handler
		btn.onClickEvent(() => {
			this.activeSection = name;
			this.redraw();
		});
	}    

	/* ---------------------------------------------------
     * RECENT SECTION
     * --------------------------------------------------- */
	private renderRecentSection(container: HTMLElement) {
		container.createEl("h3", { text: "Recent Scrobbles" });

		// Limit dropdown
		new Setting(container)
			.setName("Limit")
			.setDesc("Number of recent scrobbles to fetch")
			.addDropdown(drop => {
				["5", "10", "20", "50"].forEach(n => drop.addOption(n, n));
				drop.setValue(String(this.limit));
				drop.onChange(v => (this.limit = Number(v)));
			});

		// Fetch + Create Note
		new Setting(container)
			.setName("Actions")
			.addButton(btn =>
				btn
					.setButtonText("Fetch")
					.setCta()
					.onClick(() => this.fetchRecent(container))
			)
			.addButton(btn =>
				btn
					.setButtonText("Create Note")
                    .setCta()
					.onClick(async () => {
						await createRecentTracksNote(this.app, this.api, this.plugin);
						this.close();
					})
			);
	}

	/* ---------------------------------------------------
     * TOP TRACKS / ARTISTS / ALBUMS SECTION
     * --------------------------------------------------- */
	private renderTopSection(container: HTMLElement, type: "tracks" | "artists" | "albums") {
		container.createEl("h3", { text: `Top ${type}` });

		/* ------------------------------
         * Mode selector (period or range)
         * ------------------------------ */
		new Setting(container)
			.setName("Mode")
			.setDesc("Choose Period or From/To Date")
			.addDropdown(drop => {
				drop.addOption("period", "Period");
				drop.addOption("range", "From/To Date");
				drop.setValue(this.topMode);
				drop.onChange(v => {
					this.topMode = v as "period" | "range";
					this.redraw();
				});
			});

		/* ------------------------------
         * If Period Mode
         * ------------------------------ */
		if (this.topMode === "period") {
			new Setting(container)
				.setName("Period")
				.setDesc("Choose a Last.fm period")
				.addDropdown(drop => {
					PERIODS.forEach(p => drop.addOption(p, p));
					drop.setValue(this.topPeriod);
					drop.onChange(v => (this.topPeriod = v));
				});

			new Setting(container)
				.setName("Actions")
				.addButton(btn =>
					btn
						.setButtonText("Fetch")
						.setCta()
						.onClick(() => this.fetchTopByPeriod(container, type))
				)
				.addButton(btn =>
					btn
						.setButtonText("Create Note")
						.onClick(async () => {
							// IMPLEMENT createNoteTopTracks / Artists / Albums
							new Notice("Note creation for Top is not implemented yet.");
							this.close();
						})
				);

			return;
		}

		/* ------------------------------
         * If Range Mode
         * ------------------------------ */
		new Setting(container)
			.setName("From")
			.addText(text =>
				text
					.setPlaceholder("YYYY-MM-DD")
					.setValue(this.fromDate)
					.onChange(v => (this.fromDate = v))
			);

		new Setting(container)
			.setName("To")
			.addText(text =>
				text
					.setPlaceholder("YYYY-MM-DD")
					.setValue(this.toDate)
					.onChange(v => (this.toDate = v))
			);

		new Setting(container)
			.setName("Actions")
			.addButton(btn =>
				btn
					.setButtonText("Fetch")
					.setCta()
					.onClick(() => this.fetchTopByRange(container, type))
			)
			.addButton(btn =>
				btn
					.setButtonText("Create Note")
					.onClick(() => {
						new Notice("Note creation for Top range is not implemented yet.");
						this.close();
					})
			);
	}

	/* ---------------------------------------------------
     * FETCH: RECENT
     * --------------------------------------------------- */
	private async fetchRecent(container: HTMLElement) {
		container.createEl("p", { text: "Fetching recent tracks..." });

		try {
			const tracks = await this.api.fetchRecentScrobbles(this.limit);

			container.createEl("hr");
			container.createEl("h4", { text: `Results (${tracks.length})` });

			tracks.forEach(t => {
				const div = container.createDiv();
				div.setText(`• ${t.name} — ${t.artist.name}`);
			});
		} catch (err) {
			new Notice("Error fetching recent tracks.");
		}
	}

	/* ---------------------------------------------------
     * FETCH: TOP BY PERIOD
     * --------------------------------------------------- */
	private async fetchTopByPeriod(container: HTMLElement, type: string) {
		container.createEl("p", { text: `Fetching top ${type} (${this.topPeriod})...` });

		// Call your future API methods:
		// api.fetchTopTracks(period)
		// api.fetchTopArtists(period)
		// api.fetchTopAlbums(period)

		new Notice("Top data fetch not implemented yet.");
	}

	/* ---------------------------------------------------
     * FETCH: TOP BY RANGE (from/to weekly charts)
     * --------------------------------------------------- */
	private async fetchTopByRange(container: HTMLElement, type: string) {
		container.createEl("p", { text: `Fetching ${type} from ${this.fromDate} to ${this.toDate}...` });

		// Call your weekly route version here later
		// api.fetchWeeklyTrackChart(from, to)

		new Notice("Weekly chart fetch not implemented yet.");
	}

 /*    async runTest(contentEl: HTMLElement) {
        contentEl.empty();
        contentEl.createEl("h3", { text: "Fetching..." });

        try {
            const scrobbles: LastFmTrack[] = await this.api.fetchRecentScrobbles(this.limit);

            contentEl.empty();
            contentEl.createEl("h3", { text: `Recent Scrobbles (${scrobbles.length})` });

            scrobbles.forEach(track => {
                const container = contentEl.createEl("div", { cls: "lastfm-track-container" });
                const line = container.createEl("div", { cls: "lastfm-track-line" });
                const artist = track.artist["#text"];
                const title = track.name;
                const nowplaying = track["@attr"]?.nowplaying ? " (Now playing)" : "";

                line.setText(`• ${title} — ${artist}${nowplaying}`);
                const imgUrl = track.image?.find(img => img.size === "small")?.["#text"]
                            || track.image?.find(img => img.size === "medium")?.["#text"]
                            || track.image?.[0]?.["#text"];

                if (imgUrl && imgUrl.trim() !== "") {
                    const img = container.createEl("img", {
                        attr: {
                            src: imgUrl,
                            width: "100",
                            height: "100"
                        }
                    });
                    img.addClass("lastfm-art");
                }

            });

        } catch (err: any) {
            new Notice(`Error fetching scrobbles: ${err.message}`);
            contentEl.empty();
            contentEl.createEl("p", { text: "Failed to fetch data." });
        }
    } */
}