import { App, Notice } from "obsidian";
import { LastFmApi } from "../lastfm/api";
import type { LastFmTrack, LastFmAlbum } from "../lastfm/types";
import LastFmPlugin from "main";

export async function createRecentTracksNote(app: App, api: LastFmApi, plugin: LastFmPlugin) {
    const tracks = await api.fetchRecentScrobbles();

    const content = tracks
        .map(t => {
            const artist = t.artist.name;
            const title = t.name;
            const album = t.album?.name ?? "";
            const nowPlaying = t["@attr"]?.nowplaying ? " (Now playing)" : "";

            const imgUrl =
                t.image?.find(i => i.size === "large")?.["#text"] ||
                t.image?.find(i => i.size === "medium")?.["#text"] ||
                t.image?.find(i => i.size === "small")?.["#text"] ||
                t.image?.[0]?.["#text"] ||
                "";

            // Markdown block with image + track info
            return `### ${title} — ${artist}${nowPlaying}
${imgUrl ? `![](${imgUrl})` : ""}
Album: ${album}

`;
        })
        .join("\n");

	let folderPath = plugin.settings.folder
	
	// Create folder if it doesn't exist
	if (!app.vault.getAbstractFileByPath(folderPath)) {
    	await app.vault.createFolder(folderPath);
	}

	const fileName = `LastFM Recent Scrobbles from ${new Date().toISOString().split("T")[0]}.md`;
	const filePath = `${folderPath}/${fileName}`;

    await app.vault.create(filePath, content);

    new Notice("Last.fm note created!");
}

